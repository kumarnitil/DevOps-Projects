import boto3

# Use the 'boto3' AWS CLI profile
session = boto3.Session(profile_name='boto3')

# Create an S3 client using the boto3 profile
s3_client = session.client('s3')

# Call AWS API to list S3 buckets
response = s3_client.list_buckets()

# Print bucket names
print("S3 Buckets in your AWS Account:")
for bucket in response['Buckets']:
    print(f"- {bucket['Name']}")