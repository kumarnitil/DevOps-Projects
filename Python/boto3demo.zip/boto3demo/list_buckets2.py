import boto3

# Use the 'boto3' AWS CLI profile
session = boto3.Session(profile_name='boto3')

# Create a resource
s3_resource = session.resource('s3')

# List buckets using resource (more object-oriented)
for bucket in s3_resource.buckets.all():
    print(f"Bucket: {bucket.name}")