import boto3

# Use the 'boto3' AWS CLI profile
session = boto3.Session(profile_name='boto3')

# Create an EC2 client using the boto3 profile
ec2 = boto3.client('ec2')

# Launch an instance
response = ec2.run_instances(
    ImageId='ami-0953476d60561c955', # Example AMI ID, replace with a valid one for your region
    InstanceType='t2.micro',
    MinCount=1,
    MaxCount=1
)
instance_id = response['Instances'][0]['InstanceId']
print(f"Starting instance {instance_id}")

# Wait for the instance to be running
waiter = ec2.get_waiter('instance_running')
print("Waiting for instance to reach 'running' state...")
waiter.wait(InstanceIds=[instance_id])
print(f"Instance {instance_id} is now running")