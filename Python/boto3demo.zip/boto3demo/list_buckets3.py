import boto3

# Create a session with specific credentials (less common for general use, AWS CLI config is preferred)
session = boto3.Session(
    aws_access_key_id='YOUR ACCESS KEY',  # Best to avoid hardcoding
    aws_secret_access_key='YOUR SECRET KEY', # Best to avoid hardcoding
    region_name='us-east-1'
)

# Create clients/resources from the session
s3_from_session = session.resource('s3')
ec2_from_session = session.client('ec2')