import boto3
import time

# Use AWS CLI profile 'boto3'
session = boto3.Session(profile_name='boto3')
ec2 = session.client('ec2', region_name='us-east-1')  # Change region if needed

# Configuration
AMI_ID = 'ami-0953476d60561c955'  # Your custom AMI
INSTANCE_TYPE = 't2.micro'
KEY_NAME = 'boto3'  # Your key pair name and ensure it exists in the region already
SECURITY_GROUP_ID = 'sg-0bc379ca1d77c19f9'  # Replace with your security group ID and ensure it allows SSH access
WAIT_MINUTES = 5  # Auto-terminate after this many minutes

try:
    print("🚀 Launching EC2 instance with key pair 'boto3'...")
    
    response = ec2.run_instances(
        ImageId=AMI_ID,
        InstanceType=INSTANCE_TYPE,
        MinCount=1,
        MaxCount=1,
        KeyName=KEY_NAME,  # Attach key pair here
        SecurityGroupIds=[SECURITY_GROUP_ID],
        TagSpecifications=[{
            'ResourceType': 'instance',
            'Tags': [{
                'Key': 'Owner',
                'Value': 'Boto3User'
            }]
        }],
        UserData=f"""#!/bin/bash
        echo "Hello from Boto3" > /tmp/message.txt
        echo "Instance will self-terminate in {WAIT_MINUTES} minutes."
        sleep {WAIT_MINUTES * 60}
        """
    )

    instance_id = response['Instances'][0]['InstanceId']
    print(f"Instance {instance_id} launched. Waiting for it to be in 'running' state...")

    # Wait for instance to be running
    waiter = ec2.get_waiter('instance_running')
    waiter.wait(InstanceIds=[instance_id])
    print(f"✅ Instance {instance_id} is now running.")

    # Get Public IP (if available)
    instance_info = ec2.describe_instances(InstanceIds=[instance_id])
    public_ip = instance_info['Reservations'][0]['Instances'][0].get('PublicIpAddress', 'No Public IP')

    print(f"🔌 Public IP Address: {public_ip}")
    print(f"🔗 SSH Command: ssh -i boto3.pem ec2-user@{public_ip}")

    # Sleep before termination
    print(f"💤 Waiting {WAIT_MINUTES} minutes before terminating instance...")
    time.sleep(WAIT_MINUTES * 60)

    # Terminate instance
    print(f"🛑 Terminating instance {instance_id}...")
    ec2.terminate_instances(InstanceIds=[instance_id])

    # Wait for instance to be terminated
    term_waiter = ec2.get_waiter('instance_terminated')
    term_waiter.wait(InstanceIds=[instance_id])
    print(f"🗑️ Instance {instance_id} has been successfully terminated.")

except Exception as e:
    print(f"❌ Error: {e}")